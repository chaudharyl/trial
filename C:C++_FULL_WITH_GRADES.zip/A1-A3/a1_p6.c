/*
CH-230-A
a1_p6.c
Lalit Chaudhary
lchaudhary@jacobs-university.de
*/

#include <stdio.h>
int main (){
    char c = 'F';
   char third_character = c + 3;
    printf ("The desired character is %c and its ASCII code is %d\n", third_character, third_character);
    return 0;

}