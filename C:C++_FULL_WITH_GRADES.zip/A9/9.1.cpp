/*
CH-230-A
a9_p1.cpp
Lalit Chaudhary
lchaudhary@jacobs-university.de
*/

#include<iostream>
using namespace std;
int main()
{
	string country; 
	
	getline(cin, country); 		//gets input from user; can contain spaces 
	cout << country << endl;	//prints the name of country

	return 0;

}